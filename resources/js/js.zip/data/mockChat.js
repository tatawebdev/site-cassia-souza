export const contacts = [
];

export default { contacts };
