export default function ApplicationLogo(props) {
    return (
        <img
            src="/logo-cassia.svg"
            alt="Logo"
            {...props}
        />
    );
}
